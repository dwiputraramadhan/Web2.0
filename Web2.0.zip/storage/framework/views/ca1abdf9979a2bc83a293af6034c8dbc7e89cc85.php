<?php /* C:\Users\Putra\Downloads\Quis Web2.0_AgusHartanto_d11161002\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php */ ?>
<?php echo e($slot); ?>

