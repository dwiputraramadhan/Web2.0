<?php /* C:\xampp\htdocs\laravel\Quis Web2.0_AgusHartanto_d11161002\resources\views/products/show.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <br><br>
    <div class="row">

        <div class="col-md-3">
            <img src="<?php echo e(asset('image_files/'.$product['image_url'])); ?>" alt="..." class="img-thumbnail" height="300px" width="auto">
        </div>
        
        <div class="col-md-9">
            <h3>
                <?php echo e($product->name); ?>

            </h3>
            <h5>
               Rp. <?php echo e(number_format($product->price)); ?>

            </h5>
            <!-- rating -->
            <?php for($i = 1; $i<=5; $i++): ?>
                <?php if($i <= $rating): ?>
                <span class="fa fa-star checked"></span>
                <?php else: ?>
                <span class="fa fa-star"></span>
                <?php endif; ?>
            <?php endfor; ?>
            
            <div class="mt-2">
                <a href="https:://www.facebook.com/sharer/sharer.php?u=<?php echo e(route('products.show', ['id' => $product['id']])); ?>" class="social-button" target="_blank">
                    <span class="fa fa-facebook"></span> 
                </a> 
                <a href="https:://www.twitter.com/intent/tweet?text=my share text&amp;url=<?php echo e(route('products.show', ['id' => $product['id']])); ?>" class="social-button" target="_blank">
                    <span class="fa fa-twitter"></span> 
                </a> 
                <a href="https:://www.linkedin.com/shareArticle?mini=true&amp;url=<?php echo e(route('products.show', ['id' => $product['id']])); ?>&amp;title=my share text&amp;summary=dit is de linedin summary" class="social-button" target="_blank">
                    <span class="fa fa-linkedin"></span> 
                </a> 
                <a href="https:://www.wa.me/?text=<?php echo e(route('products.show', ['id' => $product['id']])); ?>" class="social-button" target="_blank">
                    <span class="fa fa-whatsapp"></span> 
                </a>
            </div>

            <div class="mt-4">
                <a href="<?php echo e(route('carts.add', ['id' => $product['id']])); ?>" class="btn btn-primary"><i class="fa fa-shopping-cart" aria-hidden="true"></i> Beli</a>
            </div>
            
            <div class="mt-4">
                <ul class="nav nav-tabs" role="tablist">
                    <li class="nav-item">
                        <a href="#description" class="nav-link active" role="tab" data-toggle="tab">Informasi Produk</a>
                    </li>
                    <li class="nav-item">
                        <a href="#rate" class="nav-link" role="tab" data-toggle="tab">Review Produk</a>
                    </li>
                    <li class="nav-item">
                        <a href="#review" class="nav-link" role="tab" data-toggle="tab">Ulasan</a>
                    </li>
                </ul>

                <!-- Tab panes -->
                <div class="tab-content mt-2">
                    <div class="tab-pane fade in active show" id="description" role="tabpanel">
                        <?php echo $product->description; ?>

                    </div>
                    <div class="tab-pane fade" role="tabpanel" id="rate">
                        <form action="<?php echo e(route('products.store', ['id' => $product->id])); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
                                <label><strong>Rating Produk</strong></label><br>
                                <!-- rating radio -->
                                <input type="radio" name="rating" value="1">1 <br> 
                                <input type="radio" name="rating" value="2">2 <br>
                                <input type="radio" name="rating" value="3">3 <br>
                                <input type="radio" name="rating" value="4">4 <br>
                                <input type="radio" name="rating" value="5">5 <br>
                                <div class="form-group">
                                    <label>Deskripsi</label>
                                    <textarea name="description" class="form-control" rows="3" placeholder="Deskripsi" id="ckview"></textarea>
                                </div>
                                <button type="submit" class="btn btn-primary">Submit</button>
                            </div>
                        </form>
                        <br><br>
                    </div>
                    <div class="tab-pane fade" role="tabpanel" id="review"><br>
                        <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="row blockquote review-item"><br>
                            <div class="col-md-3 text-center">
                            <img class="rounded-circle reviewer" src="http://standaloneinstaller.com/upload/avatar.png">
                            <div class="caption">
                                <small>by <a href="#"><?php echo e($review->user->name); ?></a></small>
                            </div>

                            </div>
                            <div class="col-md-9">
                            <h5>Review Produk</h5>
                            <div class="ratebox text-center" data-id="0" data-rating="5"></div>
                            <p class="review-text"><?php echo $review->description; ?>

                                <small class="review-date"><?php echo e(date('d-m-Y', strtotime($review->created_at))); ?></small>
                            </div>                          
                        </div>  
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<script src="<?php echo e(url('plugins\tinymce\jquery.tinymce.min.js')); ?>"></script>
<script src="<?php echo e(url('plugins\tinymce\tinymce.min.js')); ?>"></script>
<style>
.checked {
  color: orange;
}
</style>
<!-- tinymce js -->
<script>
tinymce.init({ selector:'#ckview' });
</script>
<?php echo $__env->make('layouts.top', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>