<?php /* D:\My Documents\Kuliah\Semester 6\Web 2.0\Quiz_Dwi Putra Ramadhan_D11161009\vendor\laravel\framework\src\Illuminate\Mail/resources/views/html/header.blade.php */ ?>
<tr>
    <td class="header">
        <a href="<?php echo e($url); ?>">
            <?php echo e($slot); ?>

        </a>
    </td>
</tr>
