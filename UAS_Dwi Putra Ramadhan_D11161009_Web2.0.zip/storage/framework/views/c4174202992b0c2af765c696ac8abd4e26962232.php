<?php /* D:\My Documents\Kuliah\Semester 6\Web 2.0\Quiz_Dwi Putra Ramadhan_D11161009\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php */ ?>
<?php echo e($slot); ?>

