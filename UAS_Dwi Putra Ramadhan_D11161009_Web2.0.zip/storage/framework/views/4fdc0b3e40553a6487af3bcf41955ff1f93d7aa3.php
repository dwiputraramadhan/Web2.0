<?php /* C:\xampp\htdocs\uts\ecomerce\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php */ ?>
<?php echo e($slot); ?>

