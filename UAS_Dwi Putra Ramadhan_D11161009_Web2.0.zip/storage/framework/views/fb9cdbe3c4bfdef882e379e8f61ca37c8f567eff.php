<?php /* C:\xampp\htdocs\laravel\Quis Web2.0_AgusHartanto_d11161002\vendor\laravel\framework\src\Illuminate\Mail/resources/views/html/header.blade.php */ ?>
<tr>
    <td class="header">
        <a href="<?php echo e($url); ?>">
            <?php echo e($slot); ?>

        </a>
    </td>
</tr>
